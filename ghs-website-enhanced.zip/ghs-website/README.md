# Global Horn Solutions Website

A professional, multi-page website for Global Horn Solutions - designed around your compass rose logo and brand identity.

## 🎨 Design Features

### Brand-Inspired Color Palette
Your website design is built directly from your logo:
- **Primary Green**: `#5FA782` - From your logo's compass and "GLOBAL" text
- **Navy**: `#1a2e35` - From your logo's background
- **Light accents and professional grays** for contrast and readability

### Visual Identity
- **Compass rose** as a central navigation theme
- Clean, modern typography (Inter font family)
- Professional card-based layouts
- Smooth animations and transitions
- Fully responsive design

## 📱 Pages Included

1. **Home**
   - Hero section with your brand colors
   - Strategic positioning overview
   - Service highlights
   - Clear calls-to-action

2. **About Us**
   - Mission and vision
   - Core values (6 principles)
   - Information about Somaliland & Berbera
   - Company advantages

3. **Our Solutions**
   - Business Advisory & Strategy
   - Trade & Market Access
   - Logistics & Supply Chain Support
   - Partnerships & Project Facilitation
   - Client segments served

4. **Why Berbera**
   - Strategic location emphasis
   - Port capabilities
   - Economic advantages
   - Key sectors and opportunities
   - Regional connectivity

5. **Contact**
   - Professional contact form
   - Contact information
   - Business hours
   - Partnership CTAs

## 🚀 Quick Start

### View Locally
Simply open `index.html` in your web browser. No server required!

### Deploy to Netlify (Recommended - 2 Minutes)

**Method 1: Drag & Drop (Easiest)**
1. Go to [https://app.netlify.com/drop](https://app.netlify.com/drop)
2. Drag the entire `ghs-website` folder onto the page
3. Your site goes live instantly with a URL like: `yoursite-123.netlify.app`
4. Optional: Connect a custom domain in Netlify settings

**Method 2: GitHub + Netlify**
1. Push this folder to a GitHub repository
2. Go to [netlify.com](https://netlify.com) and sign up
3. Click "New site from Git"
4. Connect your GitHub repo
5. Deploy settings:
   - Build command: (leave empty)
   - Publish directory: (leave empty or use `.`)
6. Click "Deploy site"

### Deploy to Vercel

1. Install Vercel CLI: `npm i -g vercel`
2. Navigate to project folder: `cd ghs-website`
3. Run: `vercel`
4. Follow the prompts
5. Your site deploys with automatic HTTPS

### Deploy to GitHub Pages

1. Create a new GitHub repository
2. Push your code to the repository
3. Go to Settings → Pages
4. Select your branch as the source
5. Your site will be available at `username.github.io/repo-name`

## 🎯 Logo Implementation

Your actual logo (`logo.jpeg`) is already integrated into the navigation bar. The website is designed to complement your logo's:
- Green compass rose
- Professional navy background
- Clean, modern aesthetic

## 📝 Customization

### Change Colors
Edit the CSS variables in `index.html` under `:root`:
```css
--color-primary: #5FA782;        /* Your logo green */
--color-navy: #1a2e35;           /* Your logo navy */
```

### Update Content
All content is in `app.js` in plain JavaScript and React components. Each page is a separate component for easy editing.

### Add Features
- Contact form backend integration
- Analytics (Google Analytics, etc.)
- Blog section
- Multi-language support
- Client testimonials

## 🌐 Custom Domain Setup

After deploying to Netlify or Vercel:

**Netlify:**
1. Go to Site Settings → Domain Management
2. Click "Add custom domain"
3. Follow DNS configuration instructions
4. Free SSL certificate is automatic

**Vercel:**
1. Go to Project Settings → Domains
2. Add your custom domain
3. Configure DNS as instructed
4. HTTPS is automatic

## 📧 Contact Form Integration

The form currently shows a success message. To make it functional:

### Option 1: Netlify Forms (Easiest)
Add `data-netlify="true"` to the `<form>` tag in app.js and Netlify handles everything.

### Option 2: Formspree
1. Sign up at [formspree.io](https://formspree.io)
2. Update form submission to POST to Formspree endpoint

### Option 3: Custom Backend
Set up your own backend (Node.js, Python, etc.) and update the form submission handler.

## 🎨 Design Philosophy

This website reflects your brand's core identity:
- **Navigation/Direction**: Like your compass logo
- **Professionalism**: Clean, modern design
- **Trust**: Your logo's green suggests growth and reliability
- **Global Reach**: International standards meet local expertise

## 📱 Responsive Design

Fully tested and optimized for:
- Desktop (1920px+)
- Laptop (1024px - 1920px)
- Tablet (768px - 1024px)
- Mobile (320px - 768px)

## 🔧 Technical Details

- **Framework**: React 18 (via CDN, no build step)
- **Styling**: Custom CSS with CSS variables
- **Fonts**: Inter (Google Fonts)
- **Icons**: Unicode emoji (universal support)
- **No dependencies** beyond React CDN

## 📂 File Structure

```
ghs-website/
├── index.html          # Main HTML with styling
├── app.js              # React application
├── logo.jpeg           # Your company logo
└── README.md           # This file
```

## 🎯 SEO Ready

- Semantic HTML structure
- Meta descriptions
- Proper heading hierarchy
- Alt text for images
- Fast loading times

## ✅ Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📞 Support Resources

- Netlify Docs: [docs.netlify.com](https://docs.netlify.com)
- Vercel Docs: [vercel.com/docs](https://vercel.com/docs)
- React Docs: [react.dev](https://react.dev)

## 🚀 Next Steps

1. ✅ Logo integrated
2. ✅ Design matches brand
3. ✅ All 5 pages complete
4. 📤 **Deploy to Netlify** (2 minutes!)
5. 🌐 Add custom domain (optional)
6. 📧 Set up contact form backend (optional)

---

**Your professional website is ready to go live!**

Built with your brand identity in mind - the compass points to success. 🧭
