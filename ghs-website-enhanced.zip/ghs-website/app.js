const { useState } = React;

// Navigation Component
const Navigation = ({ currentPage, setCurrentPage }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Us' },
    { id: 'solutions', label: 'Our Solutions' },
    { id: 'berbera', label: 'Why Berbera' },
    { id: 'contact', label: 'Contact' }
  ];

  const handleNavClick = (pageId) => {
    setCurrentPage(pageId);
    setMobileMenuOpen(false);
    window.scrollTo(0, 0);
  };

  return (
    <nav>
      <div className="nav-container">
        <a 
          href="#" 
          onClick={(e) => { e.preventDefault(); handleNavClick('home'); }} 
          className="logo-link"
        >
          <img 
            src="logo.jpeg" 
            alt="Global Horn Solutions" 
            className="logo-img"
          />
        </a>
        
        <ul className="nav-menu">
          {navItems.map(item => (
            <li key={item.id}>
              <a 
                href="#" 
                className={currentPage === item.id ? 'active' : ''}
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.id);
                }}
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>

        <button 
          className="mobile-menu-btn"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="Toggle menu"
        >
          ☰
        </button>
      </div>

      <div className={`mobile-menu ${mobileMenuOpen ? 'active' : ''}`}>
        <ul>
          {navItems.map(item => (
            <li key={item.id}>
              <a 
                href="#" 
                onClick={(e) => {
                  e.preventDefault();
                  handleNavClick(item.id);
                }}
              >
                {item.label}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </nav>
  );
};

// Home Page
const HomePage = ({ setCurrentPage }) => {
  return (
    <>
      <section className="hero">
        <div className="container hero-content fade-in">
          <h1>Connecting the Horn of Africa to Global Markets</h1>
          <p className="hero-subtitle">
            Strategic business, logistics, and trade solutions from Berbera, Somaliland. 
            We bridge local opportunities with international standards.
          </p>
          <div className="hero-buttons">
            <button className="btn btn-primary" onClick={() => setCurrentPage('solutions')}>
              Our Solutions
            </button>
            <button className="btn btn-outline" onClick={() => setCurrentPage('contact')}>
              Work With Us
            </button>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Strategic Position, Global Vision</h2>
            <p className="section-subtitle">
              Based in Berbera, Somaliland, we leverage our strategic location at the crossroads 
              of Africa, the Middle East, and Asia to deliver world-class solutions.
            </p>
          </div>

          <div className="grid grid-3">
            <div className="card fade-in">
              <div className="card-icon"><i className="fas fa-globe-africa"></i></div>
              <h3>Local Expertise</h3>
              <p>
                Deep understanding of the Horn of Africa's business landscape, culture, 
                and regional dynamics.
              </p>
            </div>

            <div className="card fade-in">
              <div className="card-icon"><i className="fas fa-handshake"></i></div>
              <h3>Global Standards</h3>
              <p>
                International best practices combined with local knowledge to deliver 
                reliable, professional solutions.
              </p>
            </div>

            <div className="card fade-in">
              <div className="card-icon"><i className="fas fa-map-marked-alt"></i></div>
              <h3>Strategic Location</h3>
              <p>
                Berbera's port and position make it an ideal gateway for trade between 
                Africa and global markets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section>
        <div className="container">
          <div className="stats-section">
            <div className="stats-grid">
              <div className="stat-item">
                <span className="stat-number"><i className="fas fa-ship"></i> 9 Days</span>
                <span className="stat-label">Jebel Ali-Berbera Service Frequency</span>
              </div>
              <div className="stat-item">
                <span className="stat-number"><i className="fas fa-users"></i> Regional</span>
                <span className="stat-label">Buyer-Supplier Connections</span>
              </div>
              <div className="stat-item">
                <span className="stat-number"><i className="fas fa-warehouse"></i> FTZ</span>
                <span className="stat-label">Berbera Free Trade Zone Access</span>
              </div>
              <div className="stat-item">
                <span className="stat-number"><i className="fas fa-globe"></i> Global</span>
                <span className="stat-label">Market Reach</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* New Trade Routes */}
      <section>
        <div className="container">
          <div className="section-header">
            <h2>Enhanced Connectivity <span className="badge badge-new">NEW</span></h2>
            <p className="section-subtitle">
              Expanded shipping routes and trade zone access for faster, more efficient logistics
            </p>
          </div>

          <div className="grid grid-2">
            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <i className="fas fa-anchor" style={{ fontSize: '2rem', color: 'var(--color-primary)' }}></i>
                <h3 style={{ margin: 0 }}>Jebel Ali-Berbera Route</h3>
              </div>
              <p>
                <strong>New enhanced service:</strong> Direct shipping connection between Jebel Ali (Dubai) 
                and Berbera Port every 9 days, providing reliable, frequent access to one of the world's 
                largest transshipment hubs.
              </p>
              <ul className="check-list mt-1">
                <li>Consistent 9-day service frequency</li>
                <li>Direct connection to Dubai's global network</li>
                <li>Reduced transit times for regional cargo</li>
                <li>Enhanced import-export capabilities</li>
              </ul>
            </div>

            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <i className="fas fa-industry" style={{ fontSize: '2rem', color: 'var(--color-primary)' }}></i>
                <h3 style={{ margin: 0 }}>Berbera Free Trade Zone</h3>
              </div>
              <p>
                Access to Berbera's Free Trade Zone offering competitive advantages for 
                manufacturing, warehousing, and trade operations with preferential customs treatment.
              </p>
              <ul className="check-list mt-1">
                <li>Duty exemptions and tax incentives</li>
                <li>Strategic warehousing facilities</li>
                <li>Simplified customs procedures</li>
                <li>Value-added processing opportunities</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Global Trade Network */}
      <div className="trade-network-section">
        <div className="container">
          <div className="section-header">
            <h2 style={{ color: 'white' }}>Berbera's Global Trade Network</h2>
            <p style={{ color: 'rgba(255,255,255,0.9)' }}>
              Strategic connections linking the Horn of Africa to major trade hubs across continents
            </p>
          </div>

          <div className="map-container">
            <svg className="trade-map" viewBox="0 0 1000 500" xmlns="http://www.w3.org/2000/svg">
              {/* Simplified world map outline */}
              <path d="M 100,250 Q 150,200 200,250 T 300,250 Q 350,230 400,250 T 500,240 Q 550,230 600,250 T 700,245 Q 750,235 800,250 T 900,250" 
                    fill="none" 
                    stroke="rgba(95, 167, 130, 0.2)" 
                    strokeWidth="1"/>
              
              {/* Continents simplified shapes */}
              {/* Africa */}
              <ellipse cx="480" cy="320" rx="80" ry="120" fill="rgba(95, 167, 130, 0.1)" stroke="rgba(95, 167, 130, 0.3)" strokeWidth="1"/>
              
              {/* Europe */}
              <ellipse cx="450" cy="180" rx="60" ry="50" fill="rgba(95, 167, 130, 0.1)" stroke="rgba(95, 167, 130, 0.3)" strokeWidth="1"/>
              
              {/* Asia */}
              <ellipse cx="700" cy="220" rx="120" ry="90" fill="rgba(95, 167, 130, 0.1)" stroke="rgba(95, 167, 130, 0.3)" strokeWidth="1"/>
              
              {/* Middle East */}
              <ellipse cx="580" cy="240" rx="50" ry="40" fill="rgba(95, 167, 130, 0.1)" stroke="rgba(95, 167, 130, 0.3)" strokeWidth="1"/>
              
              {/* Americas */}
              <ellipse cx="200" cy="250" rx="70" ry="140" fill="rgba(95, 167, 130, 0.1)" stroke="rgba(95, 167, 130, 0.3)" strokeWidth="1"/>

              {/* Trade routes - lines connecting Berbera to major hubs */}
              {/* Berbera to Dubai */}
              <line x1="510" y1="280" x2="600" y2="250" className="trade-line" strokeDasharray="8,4"/>
              
              {/* Berbera to Ethiopia */}
              <line x1="510" y1="280" x2="530" y2="300" className="trade-line" strokeDasharray="8,4"/>
              
              {/* Berbera to Middle East/Suez */}
              <line x1="510" y1="280" x2="520" y2="230" className="trade-line" strokeDasharray="8,4"/>
              
              {/* Berbera to Asia */}
              <line x1="510" y1="280" x2="720" y2="240" className="trade-line" strokeDasharray="8,4"/>
              
              {/* Berbera to Europe */}
              <line x1="510" y1="280" x2="460" y2="190" className="trade-line" strokeDasharray="8,4"/>
              
              {/* Berbera to East Africa */}
              <line x1="510" y1="280" x2="520" y2="340" className="trade-line" strokeDasharray="8,4"/>

              {/* Trade hub points */}
              {/* Dubai/Jebel Ali */}
              <circle cx="600" cy="250" className="map-point">
                <title>Jebel Ali, Dubai - 9 day service</title>
              </circle>
              
              {/* Ethiopia */}
              <circle cx="530" cy="300" className="map-point">
                <title>Ethiopia - Berbera Corridor</title>
              </circle>
              
              {/* Suez */}
              <circle cx="520" cy="230" className="map-point">
                <title>Suez Canal Route</title>
              </circle>
              
              {/* Asia */}
              <circle cx="720" cy="240" className="map-point">
                <title>Asian Markets</title>
              </circle>
              
              {/* Europe */}
              <circle cx="460" cy="190" className="map-point">
                <title>European Markets</title>
              </circle>
              
              {/* East Africa */}
              <circle cx="520" cy="340" className="map-point">
                <title>East African Markets</title>
              </circle>

              {/* Berbera - main hub (larger, different color) */}
              <circle cx="510" cy="280" className="map-point-berbera">
                <title>Berbera, Somaliland - Hub</title>
              </circle>

              {/* Labels */}
              <text x="510" y="265" textAnchor="middle" fill="white" fontSize="12" fontWeight="bold">BERBERA</text>
              <text x="600" y="240" textAnchor="middle" fill="white" fontSize="10">Dubai</text>
              <text x="530" y="315" textAnchor="middle" fill="white" fontSize="10">Ethiopia</text>
              <text x="720" y="230" textAnchor="middle" fill="white" fontSize="10">Asia</text>
              <text x="460" y="180" textAnchor="middle" fill="white" fontSize="10">Europe</text>
            </svg>

            <div className="map-legend">
              <div className="legend-item">
                <div className="legend-dot legend-dot-berbera"></div>
                <span>Berbera Hub</span>
              </div>
              <div className="legend-item">
                <div className="legend-dot legend-dot-hub"></div>
                <span>Trade Connections</span>
              </div>
              <div className="legend-item">
                <div style={{ width: '30px', height: '2px', background: 'var(--color-primary)', opacity: 0.6 }}></div>
                <span>Active Routes</span>
              </div>
            </div>
          </div>

          <div className="trade-connection-list">
            <div className="connection-card">
              <h4><i className="fas fa-ship"></i> Dubai/Jebel Ali</h4>
              <p>9-day service frequency connecting to world's largest transshipment hub</p>
            </div>
            
            <div className="connection-card">
              <h4><i className="fas fa-road"></i> Ethiopia</h4>
              <p>Direct road corridor serving landlocked Ethiopian market</p>
            </div>
            
            <div className="connection-card">
              <h4><i className="fas fa-water"></i> Suez Canal</h4>
              <p>Strategic Red Sea position for Europe-Asia trade routes</p>
            </div>
            
            <div className="connection-card">
              <h4><i className="fas fa-globe-asia"></i> Asian Markets</h4>
              <p>Direct access to China, India, and Southeast Asian economies</p>
            </div>
            
            <div className="connection-card">
              <h4><i className="fas fa-globe-europe"></i> European Markets</h4>
              <p>Mediterranean and Northern European trade connections</p>
            </div>
            
            <div className="connection-card">
              <h4><i className="fas fa-map-marked-alt"></i> East Africa</h4>
              <p>Regional network across Kenya, Tanzania, and Horn nations</p>
            </div>
          </div>
        </div>
      </div>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>What We Do</h2>
            <p className="section-subtitle">Comprehensive solutions for businesses operating in and around the Horn of Africa</p>
          </div>

          <div className="grid grid-2">
            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <i className="fas fa-chart-line" style={{ fontSize: '1.75rem', color: 'var(--color-primary)' }}></i>
                <h3 style={{ margin: 0 }}>Business Advisory</h3>
              </div>
              <p>Strategic guidance for entering and expanding in regional markets, backed by local expertise and market intelligence.</p>
            </div>

            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <i className="fas fa-network-wired" style={{ fontSize: '1.75rem', color: 'var(--color-primary)' }}></i>
                <h3 style={{ margin: 0 }}>Buyer-Supplier Connections</h3>
              </div>
              <p>Connect regional suppliers with global buyers and vice versa, facilitating trade relationships across continents.</p>
            </div>

            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <i className="fas fa-truck-loading" style={{ fontSize: '1.75rem', color: 'var(--color-primary)' }}></i>
                <h3 style={{ margin: 0 }}>Logistics Support</h3>
              </div>
              <p>Supply chain optimization, port coordination, and transportation solutions leveraging Berbera's strategic infrastructure.</p>
            </div>

            <div className="card">
              <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1rem' }}>
                <i className="fas fa-project-diagram" style={{ fontSize: '1.75rem', color: 'var(--color-primary)' }}></i>
                <h3 style={{ margin: 0 }}>Partnership Facilitation</h3>
              </div>
              <p>Connect international investors with local opportunities and navigate regulatory, cultural, and operational landscapes.</p>
            </div>
          </div>

          <div className="text-center mt-2">
            <button className="btn btn-primary" onClick={() => setCurrentPage('solutions')}>
              Explore All Solutions
            </button>
          </div>
        </div>
      </section>
    </>
  );
};

// About Page
const AboutPage = () => {
  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <h1>About Global Horn Solutions</h1>
          <p className="hero-subtitle">Trusted partners for business, trade, and development in the Horn of Africa</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="feature-section">
            <div className="feature-content">
              <h2>Our Mission</h2>
              <p>
                To be the trusted bridge between the Horn of Africa and global markets, delivering 
                professional, reliable solutions that create value for our clients and contribute to 
                regional development.
              </p>
              <p>
                We believe in the immense potential of Somaliland and the wider Horn of Africa region. 
                Our mission is to unlock that potential by providing world-class business services that 
                meet international standards while respecting and leveraging local realities.
              </p>
            </div>
            <div className="feature-image">
              <div className="compass-icon" style={{ fontSize: '8rem', color: 'rgba(255,255,255,0.9)' }}>
                🧭
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Our Values</h2>
            <p className="section-subtitle">The principles that guide everything we do</p>
          </div>

          <div className="grid grid-3">
            <div className="card">
              <h3>Integrity</h3>
              <p>
                We operate with transparency, honesty, and ethical standards in all our 
                business dealings and partnerships.
              </p>
            </div>

            <div className="card">
              <h3>Excellence</h3>
              <p>
                We deliver high-quality solutions that meet international standards while 
                remaining practical and effective in local contexts.
              </p>
            </div>

            <div className="card">
              <h3>Partnership</h3>
              <p>
                We build long-term relationships based on mutual benefit, trust, and 
                shared success with our clients and partners.
              </p>
            </div>

            <div className="card">
              <h3>Innovation</h3>
              <p>
                We continuously seek better ways to solve problems and create value, 
                adapting global best practices to regional needs.
              </p>
            </div>

            <div className="card">
              <h3>Local Impact</h3>
              <p>
                We are committed to contributing to the economic development and prosperity 
                of Somaliland and the Horn of Africa.
              </p>
            </div>

            <div className="card">
              <h3>Reliability</h3>
              <p>
                We deliver on our commitments with consistency, professionalism, and 
                attention to detail.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Why Somaliland & Berbera Matter</h2>
          </div>

          <div className="feature-section">
            <div className="feature-content">
              <h3>A Strategic Hub</h3>
              <p>
                Somaliland occupies a critical position in the Horn of Africa, offering stability, 
                a growing economy, and strategic access to regional and international markets. 
                Berbera, home to one of the region's most important ports, serves as a vital trade 
                gateway connecting Ethiopia, the Horn, and beyond to global shipping routes.
              </p>
              
              <h3 className="mt-2">Our Advantage</h3>
              <p>
                Being based in Berbera gives us unparalleled access to port facilities, 
                trade routes, and regional networks. We combine this strategic positioning 
                with deep local knowledge and international expertise to help our clients 
                navigate opportunities with confidence.
              </p>

              <ul className="check-list mt-2">
                <li>Direct access to Berbera Port and logistics infrastructure</li>
                <li>Strong relationships with local authorities and business communities</li>
                <li>Understanding of Ethiopian and regional trade dynamics</li>
                <li>Proven track record of facilitating international partnerships</li>
                <li>Commitment to regional development and economic growth</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

// Solutions Page
const SolutionsPage = ({ setCurrentPage }) => {
  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <h1>Our Solutions</h1>
          <p className="hero-subtitle">Tailored services for businesses operating in the Horn of Africa and beyond</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <i className="fas fa-chart-line" style={{ fontSize: '2.5rem', color: 'var(--color-primary)' }}></i>
              <h2 style={{ margin: 0 }}>Business Advisory & Strategy</h2>
            </div>
            <p className="mb-2">
              Navigate the complexities of doing business in the Horn of Africa with expert guidance 
              and strategic planning.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Market Entry Strategy</h4>
                <ul className="check-list">
                  <li>Market analysis and opportunity assessment</li>
                  <li>Regulatory and compliance guidance</li>
                  <li>Business setup and incorporation support</li>
                  <li>Risk assessment and mitigation planning</li>
                </ul>
              </div>
              <div>
                <h4>Business Development</h4>
                <ul className="check-list">
                  <li>Growth strategy development</li>
                  <li>Operational optimization</li>
                  <li>Stakeholder engagement</li>
                  <li>Performance monitoring and reporting</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <i className="fas fa-network-wired" style={{ fontSize: '2.5rem', color: 'var(--color-primary)' }}></i>
              <h2 style={{ margin: 0 }}>Buyer-Supplier Connections</h2>
            </div>
            <p className="mb-2">
              We connect buyers and suppliers across regional and global markets, facilitating 
              profitable trade relationships and long-term partnerships.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Regional Connections</h4>
                <ul className="check-list">
                  <li>Ethiopian buyer and supplier networks</li>
                  <li>Somaliland business community access</li>
                  <li>Horn of Africa regional producers</li>
                  <li>Local manufacturer identification</li>
                  <li>Verified supplier vetting</li>
                </ul>
              </div>
              <div>
                <h4>Global Market Access</h4>
                <ul className="check-list">
                  <li>International buyer identification</li>
                  <li>Export market research</li>
                  <li>Trade mission coordination</li>
                  <li>B2B matchmaking services</li>
                  <li>Contract negotiation support</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <i className="fas fa-truck-loading" style={{ fontSize: '2.5rem', color: 'var(--color-primary)' }}></i>
              <h2 style={{ margin: 0 }}>Logistics & Supply Chain Support</h2>
            </div>
            <p className="mb-2">
              Optimize your supply chain with our comprehensive logistics solutions centered on 
              Berbera's strategic port infrastructure and new enhanced shipping routes.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Port & Shipping Services</h4>
                <ul className="check-list">
                  <li>Berbera Port coordination and liaison</li>
                  <li>Jebel Ali-Berbera route (9-day frequency)</li>
                  <li>Freight forwarding arrangements</li>
                  <li>Cargo handling and warehousing</li>
                  <li>Free Trade Zone facilitation</li>
                  <li>Shipping documentation support</li>
                </ul>
              </div>
              <div>
                <h4>Supply Chain Optimization</h4>
                <ul className="check-list">
                  <li>Route planning and optimization</li>
                  <li>Transportation coordination</li>
                  <li>Inventory management support</li>
                  <li>Cross-border logistics</li>
                  <li>Customs clearance facilitation</li>
                  <li>Last-mile delivery solutions</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' }}>
              <i className="fas fa-project-diagram" style={{ fontSize: '2.5rem', color: 'var(--color-primary)' }}></i>
              <h2 style={{ margin: 0 }}>Partnerships & Project Facilitation</h2>
            </div>
            <p className="mb-2">
              Bridge the gap between international investors and local opportunities with our 
              facilitation and partnership services.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Investment Facilitation</h4>
                <ul className="check-list">
                  <li>Opportunity identification and screening</li>
                  <li>Due diligence support</li>
                  <li>Local partner identification</li>
                  <li>Regulatory navigation</li>
                </ul>
              </div>
              <div>
                <h4>Project Management</h4>
                <ul className="check-list">
                  <li>Project planning and coordination</li>
                  <li>Stakeholder management</li>
                  <li>Implementation oversight</li>
                  <li>Progress monitoring and reporting</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Who We Serve</h2>
            <p className="section-subtitle">Customized solutions for diverse clients</p>
          </div>

          <div className="grid grid-3">
            <div className="card">
              <i className="fas fa-building" style={{ fontSize: '2rem', color: 'var(--color-primary)', marginBottom: '1rem' }}></i>
              <h3>International Businesses</h3>
              <p>Companies looking to enter or expand in the Horn of Africa market with reliable local support.</p>
            </div>

            <div className="card">
              <i className="fas fa-boxes" style={{ fontSize: '2rem', color: 'var(--color-primary)', marginBottom: '1rem' }}></i>
              <h3>African Exporters</h3>
              <p>Local and regional producers seeking access to international markets and global value chains.</p>
            </div>

            <div className="card">
              <i className="fas fa-hands-helping" style={{ fontSize: '2rem', color: 'var(--color-primary)', marginBottom: '1rem' }}></i>
              <h3>Development Organizations</h3>
              <p>NGOs and development agencies requiring local expertise for project implementation.</p>
            </div>

            <div className="card">
              <i className="fas fa-shipping-fast" style={{ fontSize: '2rem', color: 'var(--color-primary)', marginBottom: '1rem' }}></i>
              <h3>Logistics Companies</h3>
              <p>International freight and logistics firms needing local coordination in Berbera and the region.</p>
            </div>

            <div className="card">
              <i className="fas fa-chart-pie" style={{ fontSize: '2rem', color: 'var(--color-primary)', marginBottom: '1rem' }}></i>
              <h3>Investors</h3>
              <p>Private equity, venture capital, and individual investors exploring opportunities in the Horn.</p>
            </div>

            <div className="card">
              <i className="fas fa-landmark" style={{ fontSize: '2rem', color: 'var(--color-primary)', marginBottom: '1rem' }}></i>
              <h3>Government Entities</h3>
              <p>Public sector organizations seeking expertise on trade, logistics, and regional development.</p>
            </div>
          </div>

          <div className="text-center mt-2">
            <button className="btn btn-primary" onClick={() => setCurrentPage('contact')}>
              Discuss Your Needs
            </button>
          </div>
        </div>
      </section>
    </>
  );
};
  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <h1>Our Solutions</h1>
          <p className="hero-subtitle">Tailored services for businesses operating in the Horn of Africa and beyond</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <h2>Business Advisory & Strategy</h2>
            <p className="mb-2">
              Navigate the complexities of doing business in the Horn of Africa with expert guidance 
              and strategic planning.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Market Entry Strategy</h4>
                <ul className="check-list">
                  <li>Market analysis and opportunity assessment</li>
                  <li>Regulatory and compliance guidance</li>
                  <li>Business setup and incorporation support</li>
                  <li>Risk assessment and mitigation planning</li>
                </ul>
              </div>
              <div>
                <h4>Business Development</h4>
                <ul className="check-list">
                  <li>Growth strategy development</li>
                  <li>Operational optimization</li>
                  <li>Stakeholder engagement</li>
                  <li>Performance monitoring and reporting</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <h2>Trade & Market Access</h2>
            <p className="mb-2">
              Connect African producers with global buyers and facilitate seamless international trade.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Export Development</h4>
                <ul className="check-list">
                  <li>International buyer identification</li>
                  <li>Market research and intelligence</li>
                  <li>Export documentation and compliance</li>
                  <li>Quality standards and certification support</li>
                </ul>
              </div>
              <div>
                <h4>Import Facilitation</h4>
                <ul className="check-list">
                  <li>Supplier sourcing and verification</li>
                  <li>Import licensing and permits</li>
                  <li>Customs clearance coordination</li>
                  <li>Distribution network development</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <h2>Logistics & Supply Chain Support</h2>
            <p className="mb-2">
              Optimize your supply chain with our comprehensive logistics solutions centered on 
              Berbera's strategic port infrastructure.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Port & Shipping Services</h4>
                <ul className="check-list">
                  <li>Berbera Port coordination and liaison</li>
                  <li>Freight forwarding arrangements</li>
                  <li>Cargo handling and warehousing</li>
                  <li>Shipping documentation support</li>
                </ul>
              </div>
              <div>
                <h4>Supply Chain Optimization</h4>
                <ul className="check-list">
                  <li>Route planning and optimization</li>
                  <li>Transportation coordination</li>
                  <li>Inventory management support</li>
                  <li>Cross-border logistics</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card mb-2">
            <h2>Partnerships & Project Facilitation</h2>
            <p className="mb-2">
              Bridge the gap between international investors and local opportunities with our 
              facilitation and partnership services.
            </p>
            
            <div className="grid grid-2">
              <div>
                <h4>Investment Facilitation</h4>
                <ul className="check-list">
                  <li>Opportunity identification and screening</li>
                  <li>Due diligence support</li>
                  <li>Local partner identification</li>
                  <li>Regulatory navigation</li>
                </ul>
              </div>
              <div>
                <h4>Project Management</h4>
                <ul className="check-list">
                  <li>Project planning and coordination</li>
                  <li>Stakeholder management</li>
                  <li>Implementation oversight</li>
                  <li>Progress monitoring and reporting</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Who We Serve</h2>
            <p className="section-subtitle">Customized solutions for diverse clients</p>
          </div>

          <div className="grid grid-3">
            <div className="card">
              <h3>International Businesses</h3>
              <p>Companies looking to enter or expand in the Horn of Africa market with reliable local support.</p>
            </div>

            <div className="card">
              <h3>African Exporters</h3>
              <p>Local and regional producers seeking access to international markets and global value chains.</p>
            </div>

            <div className="card">
              <h3>Development Organizations</h3>
              <p>NGOs and development agencies requiring local expertise for project implementation.</p>
            </div>

            <div className="card">
              <h3>Logistics Companies</h3>
              <p>International freight and logistics firms needing local coordination in Berbera and the region.</p>
            </div>

            <div className="card">
              <h3>Investors</h3>
              <p>Private equity, venture capital, and individual investors exploring opportunities in the Horn.</p>
            </div>

            <div className="card">
              <h3>Government Entities</h3>
              <p>Public sector organizations seeking expertise on trade, logistics, and regional development.</p>
            </div>
          </div>

          <div className="text-center mt-2">
            <button className="btn btn-primary" onClick={() => setCurrentPage('contact')}>
              Discuss Your Needs
            </button>
          </div>
        </div>
      </section>
    </>
  );
};

// Berbera Page
const BerberaPage = () => {
  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <h1>Why Berbera & Somaliland</h1>
          <p className="hero-subtitle">A strategic gateway at the crossroads of global trade</p>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Strategic Location</h2>
            <p className="section-subtitle">
              Berbera sits at one of the world's most strategic maritime locations, offering 
              unparalleled access to key markets and trade routes.
            </p>
          </div>

          <div className="grid grid-2">
            <div className="card">
              <h3>Maritime Gateway</h3>
              <p>
                Located on the Gulf of Aden, Berbera provides direct access to one of the world's 
                busiest shipping lanes, connecting Europe, Asia, and Africa.
              </p>
              <ul className="check-list mt-1">
                <li>Direct Red Sea access</li>
                <li>Proximity to Bab-el-Mandeb strait</li>
                <li>Modern port infrastructure</li>
                <li>Deep-water capabilities</li>
              </ul>
            </div>

            <div className="card">
              <h3>Regional Hub</h3>
              <p>
                Berbera serves as a critical trade corridor for Ethiopia and the wider Horn of Africa, 
                handling significant volumes of regional import and export cargo.
              </p>
              <ul className="check-list mt-1">
                <li>Ethiopian trade corridor</li>
                <li>Regional connectivity</li>
                <li>Cross-border infrastructure</li>
                <li>Growing trade volumes</li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Economic Advantages</h2>
          </div>

          <div className="grid grid-3">
            <div className="card">
              <div className="card-icon"><i className="fas fa-chart-line"></i></div>
              <h3>Stable Business Environment</h3>
              <p>
                Somaliland offers political stability, a functioning legal system, and a 
                business-friendly regulatory environment.
              </p>
            </div>

            <div className="card">
              <div className="card-icon"><i className="fas fa-dollar-sign"></i></div>
              <h3>Competitive Costs</h3>
              <p>
                Lower operational costs compared to neighboring countries while maintaining 
                professional standards and infrastructure quality.
              </p>
            </div>

            <div className="card">
              <div className="card-icon"><i className="fas fa-rocket"></i></div>
              <h3>Growth Potential</h3>
              <p>
                Rapidly developing economy with significant opportunities in trade, logistics, 
                infrastructure, and various sectors.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="feature-section">
            <div className="feature-content">
              <h2>Berbera Port: A Modern Facility</h2>
              <p>
                The Port of Berbera has undergone significant modernization, transforming it into 
                a world-class facility capable of handling large vessels and high cargo volumes.
              </p>

              <h3 className="mt-2">Port Capabilities</h3>
              <ul className="check-list">
                <li>14.5-meter draft for large vessels</li>
                <li>Modern container terminal</li>
                <li>Advanced cargo handling equipment</li>
                <li>Expanded storage capacity</li>
                <li>Efficient customs procedures</li>
                <li>24/7 operational capacity</li>
              </ul>

              <h3 className="mt-2">Connectivity</h3>
              <ul className="check-list">
                <li>Road corridor to Ethiopia (Berbera Corridor)</li>
                <li>Regional transport links</li>
                <li>Air freight capabilities</li>
                <li>International shipping lines</li>
              </ul>
            </div>
            <div className="feature-image">
              <div style={{ fontSize: '8rem', color: 'rgba(255,255,255,0.9)' }}>
                🚢
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Why Global Horn Solutions</h2>
            <p className="section-subtitle">Our local presence makes the difference</p>
          </div>

          <div className="grid grid-2">
            <div className="card">
              <h3>Deep Local Knowledge</h3>
              <p>
                We understand the nuances of doing business in Somaliland—from regulatory requirements 
                to cultural considerations—giving you a competitive advantage.
              </p>
            </div>

            <div className="card">
              <h3>Established Networks</h3>
              <p>
                Our relationships with port authorities, customs, logistics providers, and business 
                communities ensure smooth operations and problem resolution.
              </p>
            </div>

            <div className="card">
              <h3>On-the-Ground Support</h3>
              <p>
                Being physically present in Berbera means we can provide immediate assistance, 
                coordinate activities, and respond quickly to your needs.
              </p>
            </div>

            <div className="card">
              <h3>Regional Expertise</h3>
              <p>
                Our understanding extends beyond Somaliland to the wider Horn of Africa, helping 
                you navigate cross-border opportunities and regional dynamics.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Key Sectors & Opportunities</h2>
          </div>

          <div className="grid grid-3">
            <div className="card">
              <h3>Livestock Trade</h3>
              <p>Major export sector with access to Middle Eastern markets and growing international demand.</p>
            </div>

            <div className="card">
              <h3>Logistics & Transport</h3>
              <p>Growing demand for warehousing, freight forwarding, and supply chain services.</p>
            </div>

            <div className="card">
              <h3>Infrastructure Development</h3>
              <p>Ongoing port expansion and road development creating significant opportunities.</p>
            </div>

            <div className="card">
              <h3>Trade Services</h3>
              <p>Import-export facilitation, customs brokerage, and cargo handling services.</p>
            </div>

            <div className="card">
              <h3>Fisheries</h3>
              <p>Rich marine resources with potential for sustainable development and export.</p>
            </div>

            <div className="card">
              <h3>Energy</h3>
              <p>Renewable energy opportunities including solar and wind power development.</p>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

// Contact Page
const ContactPage = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    interest: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <>
      <section className="hero">
        <div className="container hero-content">
          <h1>Get in Touch</h1>
          <p className="hero-subtitle">Let's discuss how we can support your business in the Horn of Africa</p>
        </div>
      </section>

      <section>
        <div className="container">
          {!submitted ? (
            <div className="contact-form">
              <div className="section-header">
                <h2>Start a Conversation</h2>
                <p>
                  Whether you're exploring market entry, need logistics support, or seeking 
                  partnerships, we're here to help.
                </p>
              </div>

              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="name">Full Name *</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    required
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="John Doe"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="email">Email Address *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    required
                    value={formData.email}
                    onChange={handleChange}
                    placeholder="john@company.com"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="company">Company / Organization</label>
                  <input
                    type="text"
                    id="company"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    placeholder="Your Company Name"
                  />
                </div>

                <div className="form-group">
                  <label htmlFor="interest">Area of Interest *</label>
                  <select
                    id="interest"
                    name="interest"
                    required
                    value={formData.interest}
                    onChange={handleChange}
                  >
                    <option value="">Select an option</option>
                    <option value="business-advisory">Business Advisory & Strategy</option>
                    <option value="trade">Trade & Market Access</option>
                    <option value="logistics">Logistics & Supply Chain</option>
                    <option value="partnerships">Partnerships & Projects</option>
                    <option value="general">General Inquiry</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="form-group">
                  <label htmlFor="message">Message *</label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    value={formData.message}
                    onChange={handleChange}
                    placeholder="Tell us about your needs and how we can help..."
                  />
                </div>

                <button type="submit" className="btn btn-primary" style={{ width: '100%' }}>
                  Send Message
                </button>
              </form>
            </div>
          ) : (
            <div className="contact-form text-center">
              <div style={{ fontSize: '3rem', marginBottom: '1rem', color: 'var(--color-primary)' }}>✓</div>
              <h2>Thank You!</h2>
              <p>
                We've received your message and will get back to you within 24-48 hours.
              </p>
              <button 
                className="btn btn-primary mt-2"
                onClick={() => setSubmitted(false)}
              >
                Send Another Message
              </button>
            </div>
          )}
        </div>
      </section>

      <section>
        <div className="container">
          <div className="section-header">
            <h2>Other Ways to Reach Us</h2>
          </div>

          <div className="grid grid-3">
            <div className="card text-center">
              <div className="card-icon">📧</div>
              <h3>Email</h3>
              <p><a href="mailto:info@globalhornsolutions.com">info@globalhornsolutions.com</a></p>
            </div>

            <div className="card text-center">
              <div className="card-icon">📍</div>
              <h3>Location</h3>
              <p>Berbera, Somaliland</p>
            </div>

            <div className="card text-center">
              <div className="card-icon">💼</div>
              <h3>Business Hours</h3>
              <p>Sunday - Thursday<br />8:00 AM - 5:00 PM EAT</p>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section>
        <div className="container">
          <div className="section-header">
            <h2>Frequently Asked Questions</h2>
            <p>Quick answers to common inquiries about our services</p>
          </div>

          <div style={{ maxWidth: '900px', margin: '0 auto' }}>
            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                How long does customs clearance take at Berbera Port?
              </div>
              <div className="faq-answer">
                With proper documentation, customs clearance typically takes 24-48 hours. We work closely with port authorities to expedite the process and can assist with pre-clearance documentation to minimize delays.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                Do you handle cargo destined for Ethiopia?
              </div>
              <div className="faq-answer">
                Yes, we specialize in Ethiopian cargo via the Berbera Corridor. We coordinate port operations, customs clearance, and can arrange onward transportation to major Ethiopian cities including Addis Ababa, Dire Dawa, and other destinations.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                What documentation is required for import/export through Berbera?
              </div>
              <div className="faq-answer">
                Standard requirements include: Bill of Lading, Commercial Invoice, Packing List, Certificate of Origin, and relevant permits depending on cargo type. We provide detailed documentation guidance and can assist with preparation and submission.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                Can you help connect us with suppliers or buyers in the region?
              </div>
              <div className="faq-answer">
                Absolutely. We maintain extensive networks of verified suppliers and buyers across the Horn of Africa and internationally. Our matchmaking services include vetting, introduction, and support throughout the negotiation process.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                What are your service fees?
              </div>
              <div className="faq-answer">
                Our fees vary based on service type, cargo volume, and complexity. We offer competitive, transparent pricing and provide detailed quotes after understanding your specific requirements. Contact us for a customized proposal.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                How can businesses access the Berbera Free Trade Zone?
              </div>
              <div className="faq-answer">
                We facilitate FTZ access by guiding you through registration, helping secure warehousing space, and coordinating with FTZ authorities. Benefits include duty exemptions, simplified procedures, and strategic positioning for regional distribution.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <i className="fas fa-question-circle" style={{ color: 'var(--color-primary)', marginRight: '0.5rem' }}></i>
                What is the Jebel Ali-Berbera service frequency?
              </div>
              <div className="faq-answer">
                The enhanced Dubai (Jebel Ali) to Berbera shipping service operates every 9 days, providing reliable and frequent connections to one of the world's largest transshipment hubs. This enables efficient cargo flows between the Gulf and Horn of Africa.
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="container">
          <div className="card" style={{ 
            background: 'linear-gradient(135deg, var(--color-navy) 0%, var(--color-navy-light) 100%)', 
            color: 'white',
            padding: 'var(--spacing-lg)'
          }}>
            <div className="text-center">
              <h2 style={{ color: 'white' }}>Ready to Explore Opportunities?</h2>
              <p style={{ color: 'rgba(255,255,255,0.9)', maxWidth: '700px', margin: '0 auto 2rem' }}>
                Whether you're a multinational corporation, African exporter, investor, or development 
                organization, we're ready to discuss how Global Horn Solutions can support your objectives 
                in the Horn of Africa.
              </p>
              <div className="grid grid-2" style={{ maxWidth: '600px', margin: '0 auto' }}>
                <div>
                  <h4 style={{ color: 'var(--color-primary)', marginBottom: '0.5rem' }}>Partnership Inquiries</h4>
                  <p style={{ color: 'rgba(255,255,255,0.9)' }}>Strategic collaborations and joint ventures</p>
                </div>
                <div>
                  <h4 style={{ color: 'var(--color-primary)', marginBottom: '0.5rem' }}>Project Support</h4>
                  <p style={{ color: 'rgba(255,255,255,0.9)' }}>Implementation and facilitation services</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

// Footer Component
const Footer = ({ setCurrentPage }) => {
  return (
    <footer>
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <h4>Global Horn Solutions</h4>
            <p>
              Connecting the Horn of Africa to global markets through trusted business, 
              logistics, and trade solutions.
            </p>
            <p style={{ marginTop: '1rem' }}>
              <strong>Based in Berbera, Somaliland</strong>
            </p>
          </div>

          <div className="footer-section">
            <h4>Quick Links</h4>
            <p><a href="#" onClick={(e) => { e.preventDefault(); setCurrentPage('home'); window.scrollTo(0,0); }}>Home</a></p>
            <p><a href="#" onClick={(e) => { e.preventDefault(); setCurrentPage('about'); window.scrollTo(0,0); }}>About Us</a></p>
            <p><a href="#" onClick={(e) => { e.preventDefault(); setCurrentPage('solutions'); window.scrollTo(0,0); }}>Our Solutions</a></p>
            <p><a href="#" onClick={(e) => { e.preventDefault(); setCurrentPage('berbera'); window.scrollTo(0,0); }}>Why Berbera</a></p>
            <p><a href="#" onClick={(e) => { e.preventDefault(); setCurrentPage('contact'); window.scrollTo(0,0); }}>Contact</a></p>
          </div>

          <div className="footer-section">
            <h4>Connect With Us</h4>
            <p>Email: <a href="mailto:info@globalhornsolutions.com">info@globalhornsolutions.com</a></p>
            <p>Location: Berbera, Somaliland</p>
            <p style={{ marginTop: '1rem', fontSize: '0.9rem' }}>
              Business Hours:<br />
              Sunday - Thursday, 8:00 AM - 5:00 PM EAT
            </p>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; 2025 Global Horn Solutions. All rights reserved.</p>
          <p style={{ marginTop: '0.5rem', fontSize: '0.9rem' }}>
            Professional business, logistics, and trade solutions in the Horn of Africa
          </p>
        </div>
      </div>
    </footer>
  );
};

// Main App Component
const App = () => {
  const [currentPage, setCurrentPage] = useState('home');

  const renderPage = () => {
    switch (currentPage) {
      case 'home':
        return <HomePage setCurrentPage={setCurrentPage} />;
      case 'about':
        return <AboutPage />;
      case 'solutions':
        return <SolutionsPage setCurrentPage={setCurrentPage} />;
      case 'berbera':
        return <BerberaPage />;
      case 'contact':
        return <ContactPage />;
      default:
        return <HomePage setCurrentPage={setCurrentPage} />;
    }
  };

  return (
    <>
      <Navigation currentPage={currentPage} setCurrentPage={setCurrentPage} />
      <main>
        {renderPage()}
      </main>
      <Footer setCurrentPage={setCurrentPage} />
      
      {/* WhatsApp Floating Button */}
      <a 
        href="https://wa.me/252634000000" 
        className="whatsapp-float" 
        target="_blank" 
        rel="noopener noreferrer"
        aria-label="Contact us on WhatsApp"
      >
        <i className="fab fa-whatsapp"></i>
      </a>
    </>
  );
};

// Render the app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
